const screens = [...document.querySelectorAll(".screen")];
const toast = document.getElementById("toast");

function showScreen(id) {
  screens.forEach(screen => screen.classList.toggle("active", screen.id === id));
  window.scrollTo({ top: 0, behavior: "smooth" });
}
document.getElementById("openGift").addEventListener("click", () => showScreen("letter"));
document.querySelectorAll(".next-button").forEach(button => {
  button.addEventListener("click", () => showScreen(button.dataset.next));
});
document.getElementById("restart").addEventListener("click", () => showScreen("home"));

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timeout);
  showToast.timeout = window.setTimeout(() => toast.classList.remove("show"), 2400);
}

document.querySelectorAll(".message-card").forEach(card => {
  card.addEventListener("click", () => {
    document.getElementById("revealText").textContent = card.dataset.message;
    document.querySelectorAll(".message-card").forEach(item => item.classList.remove("selected"));
    card.classList.add("selected");
  });
});

const questions = [
  {
    question: "Qual dessas opções combina mais com um dia perfeito?",
    answers: ["Um dia tranquilo e aconchegante", "Uma aventura inesperada", "Comida boa e nenhuma preocupação"],
    feedback: ["Conforto e paz: uma escolha respeitável. ☾", "A energia de quem transforma qualquer dia em história. ✦", "Prioridades absolutamente corretas. ♡"]
  },
  {
    question: "Escolha seu companheiro oficial de aventuras:",
    answers: ["Um coelhinho fofo", "Um gatinho de personalidade", "Uma playlist que entende tudo"],
    feedback: ["Bunny supremacy. Não temos argumentos contra.", "Pequeno, misterioso e provavelmente julgando todo mundo.", "Às vezes uma música explica melhor que mil palavras."]
  },
  {
    question: "O que fazer quando o dia não colabora?",
    answers: ["Dar uma pausa e respirar", "Procurar algo gostoso para comer", "Mandar mensagem para alguém especial"],
    feedback: ["Se cuidar também é uma conquista.", "A ciência ainda não explicou o poder de um lanchinho.", "Boa escolha. Pessoas queridas fazem diferença. ♡"]
  }
];
let questionIndex = 0;
function renderQuestion() {
  const item = questions[questionIndex];
  document.getElementById("questionText").textContent = item.question;
  document.getElementById("quizCount").textContent = `PERGUNTA 0${questionIndex + 1} / 03`;
  document.getElementById("quizProgress").style.width = `${((questionIndex + 1) / questions.length) * 100}%`;
  const options = document.getElementById("quizOptions");
  options.innerHTML = "";
  item.answers.forEach((answer, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "quiz-option";
    button.textContent = answer;
    button.addEventListener("click", () => {
      document.getElementById("quizFeedback").textContent = item.feedback[index];
      [...options.children].forEach(option => option.disabled = true);
      if (questionIndex < questions.length - 1) {
        const next = document.createElement("button");
        next.type = "button";
        next.className = "text-button";
        next.textContent = "Próxima pergunta →";
        next.addEventListener("click", () => {
          questionIndex += 1;
          document.getElementById("quizFeedback").textContent = "";
          renderQuestion();
        });
        options.appendChild(next);
      } else {
        const done = document.createElement("p");
        done.className = "quiz-feedback";
        done.textContent = "Resultado oficial: você continua sendo a Bunny. Parabéns! ♡";
        options.appendChild(done);
      }
    });
    options.appendChild(button);
  });
}
renderQuestion();

const soundToggle = document.getElementById("soundToggle");
const music = document.getElementById("backgroundMusic");
soundToggle.addEventListener("click", async () => {
  if (music.paused) {
    try {
      await music.play();
      soundToggle.setAttribute("aria-pressed", "true");
      document.getElementById("soundLabel").textContent = "Som ligado";
    } catch {
      showToast("Adicione sua música em assets/music/trilha.mp3 primeiro.");
    }
  } else {
    music.pause();
    soundToggle.setAttribute("aria-pressed", "false");
    document.getElementById("soundLabel").textContent = "Som desligado";
  }
});

// Pequenas estrelas decorativas geradas sem imagens externas.
const starLayer = document.querySelector(".stars");
for (let i = 0; i < 22; i++) {
  const star = document.createElement("span");
  star.textContent = i % 3 === 0 ? "✦" : "·";
  star.style.position = "absolute";
  star.style.left = `${(i * 47 + 11) % 97}%`;
  star.style.top = `${(i * 71 + 8) % 95}%`;
  star.style.color = i % 2 ? "#cbb2ed" : "#fff";
  star.style.fontSize = `${8 + (i % 4) * 4}px`;
  star.style.opacity = ".45";
  star.style.animation = `twinkle ${2 + (i % 4)}s ease-in-out ${i % 3}s infinite`;
  starLayer.appendChild(star);
}
