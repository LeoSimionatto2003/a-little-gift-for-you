# A Little Gift for You — Bunny Edition

Presente digital em HTML, CSS e JavaScript puro, pensado para abrir pelo celular via QR Code.

## Como visualizar
1. Extraia a pasta.
2. Abra `index.html` no navegador.
3. Para uma experiência mais próxima da hospedagem, use a extensão Live Server no VS Code.

## Personalizações importantes
- O nome e apelido aparecem em `index.html`.
- A carta principal está na seção `letter` de `index.html`.
- Os cartões de mensagens estão na seção `little-things`.
- As perguntas e respostas do mini quiz estão em `js/script.js`.
- A trilha sonora é opcional: coloque um arquivo MP3 chamado `trilha.mp3` em `assets/music/`.

## Publicar e gerar QR Code
Você pode publicar a pasta no GitHub Pages ou Netlify. Depois de obter o endereço público do site, gere um QR Code apontando para esse endereço e imprima no cartão que vai dentro da caixa.

## Observações
- O site é responsivo e prioriza celular.
- Não usa imagens externas nem reproduz personagens oficiais; a inspiração visual está na paleta e nos detalhes.
- A música começa somente após a pessoa tocar no botão de som, respeitando as regras dos navegadores.
