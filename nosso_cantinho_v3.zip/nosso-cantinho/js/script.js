/* Nosso cantinho — frontend estático com sincronização opcional via Supabase */
(() => {
  const $ = (s) => document.querySelector(s);
  const STORE_KEY = "nosso-cantinho-local-v1";
  const CONFIG_KEY = "nosso-cantinho-supabase-v1";
  const ROOM_KEY = "nosso-cantinho-room-v1";
  let supabase = null, user = null, roomId = localStorage.getItem(ROOM_KEY), filter = "Todas";
  let data = loadLocal();

  function loadLocal(){ try{return JSON.parse(localStorage.getItem(STORE_KEY)) || {ideas:[],memories:[],songs:[]};}catch{return {ideas:[],memories:[],songs:[]};} }
  function saveLocal(){localStorage.setItem(STORE_KEY,JSON.stringify(data));}
  function uid(){return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;}
  function esc(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600);}
  function setMessage(msg){$("#settingsMessage").textContent=msg;}
  function dateLabel(value){return new Date(value).toLocaleDateString("pt-BR",{day:"2-digit",month:"short",year:"numeric"});}
  function anniversary(){
    const start=new Date(2025,10,9,0,0,0), now=new Date();
    let years=now.getFullYear()-start.getFullYear();
    let anniversaryThisYear=new Date(now.getFullYear(),10,9);
    if(now<anniversaryThisYear) years--;
    const last=new Date(start.getFullYear()+years,10,9);
    const days=Math.floor((new Date(now.getFullYear(),now.getMonth(),now.getDate())-last)/86400000);
    $("#elapsed").textContent=`${years} ${years===1?"ano":"anos"} e ${days} ${days===1?"dia":"dias"}`;
    let nextYear=now.getFullYear(); if(now>=anniversaryThisYear) nextYear++;
    const next=new Date(nextYear,10,9), diff=Math.ceil((next-new Date(now.getFullYear(),now.getMonth(),now.getDate()))/86400000);
    $("#nextAnniversary").textContent=next.toLocaleDateString("pt-BR",{day:"2-digit",month:"long",year:"numeric"});
    $("#countdown").textContent=diff===1?"Falta 1 dia":`Faltam ${diff} dias`;
  }
  anniversary();

  function render(){
    renderIdeas();renderMemories();renderSongs();
  }
  function renderIdeas(){
    const list=$("#ideasList"), items=data.ideas.filter(x=>filter==="Todas"||x.category===filter).sort((a,b)=>Number(a.done)-Number(b.done));
    list.innerHTML=items.length?items.map(x=>`<article class="idea-item ${x.done?"done":""}"><input class="idea-check" type="checkbox" data-done="${esc(x.id)}" ${x.done?"checked":""} aria-label="Marcar como concluída"><div class="idea-main"><strong>${esc(x.title)}</strong><small>${esc(x.category)} · ${dateLabel(x.created_at)}</small></div><button class="delete-btn" data-delete-idea="${esc(x.id)}" aria-label="Excluir">×</button></article>`).join(""):`<div class="empty-state">Ainda não tem ideia nessa categoria. Adicionem a primeira. ♡</div>`;
  }
  function renderMemories(){
    const list=$("#memoriesList"), items=[...data.memories].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
    list.innerHTML=items.length?items.map(x=>`<article class="memory-card"><small>${dateLabel(x.created_at)}</small><h3>${esc(x.title)}</h3><p>${esc(x.body||"")}</p><button class="delete-btn" data-delete-memory="${esc(x.id)}" aria-label="Excluir memória">×</button></article>`).join(""):`<div class="empty-state">As memórias que vocês guardarem vão aparecer aqui.</div>`;
  }
  function renderSongs(){
    const list=$("#songsList"), items=[...data.songs].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
    list.innerHTML=items.length?items.map(x=>`<article class="song-item"><span class="music-icon">♫</span><div class="idea-main"><strong>${esc(x.title)}</strong>${x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener">Abrir música ↗</a>`:"<small>Adicionada à playlist</small>"}</div><button class="delete-btn" data-delete-song="${esc(x.id)}" aria-label="Excluir música">×</button></article>`).join(""):`<div class="empty-state">A playlist de vocês começa com a primeira música.</div>`;
  }
  async function persist(type,item,remove=false){
    const arr=data[type], idx=arr.findIndex(x=>x.id===item.id);
    if(remove){if(idx>=0)arr.splice(idx,1);}else if(idx>=0)arr[idx]=item;else arr.push(item);
    saveLocal();render();
    if(supabase&&user&&roomId){
      try{
        if(remove){const {error}=await supabase.from("shared_items").delete().eq("id",item.id).eq("room_id",roomId);if(error)throw error;}
        else {const row={id:item.id,room_id:roomId,kind:type,payload:item,created_by:user.id};const {error}=await supabase.from("shared_items").upsert(row);if(error)throw error;}
      }catch(e){toast("Salvo neste dispositivo, mas não sincronizou: "+e.message);}
    }else toast("Salvo neste dispositivo. Para compartilhar, conecte o espaço.");
  }
  $("#ideaForm").addEventListener("submit",async e=>{e.preventDefault();const title=$("#ideaTitle").value.trim();if(!title)return;await persist("ideas",{id:uid(),title,category:$("#ideaCategory").value,done:false,created_at:new Date().toISOString()});e.target.reset();});
  $("#memoryForm").addEventListener("submit",async e=>{e.preventDefault();const title=$("#memoryTitle").value.trim();if(!title)return;await persist("memories",{id:uid(),title,body:$("#memoryBody").value.trim(),created_at:new Date().toISOString()});e.target.reset();});
  $("#songForm").addEventListener("submit",async e=>{e.preventDefault();const title=$("#songTitle").value.trim(),url=$("#songUrl").value.trim();if(!title)return;if(url&&!/^https?:\/\//i.test(url)){toast("Use um link começando com http:// ou https://");return;}await persist("songs",{id:uid(),title,url,created_at:new Date().toISOString()});e.target.reset();});
  $("#ideasList").addEventListener("change",async e=>{const id=e.target.dataset.done;if(!id)return;const item=data.ideas.find(x=>x.id===id);if(item)await persist("ideas",{...item,done:e.target.checked});});
  document.body.addEventListener("click",async e=>{
    const del=e.target.closest("[data-delete-idea],[data-delete-memory],[data-delete-song]");
    if(del){const kind=del.hasAttribute("data-delete-idea")?"ideas":del.hasAttribute("data-delete-memory")?"memories":"songs";const id=del.dataset.deleteIdea||del.dataset.deleteMemory||del.dataset.deleteSong;const item=data[kind].find(x=>x.id===id);if(item&&confirm("Excluir este item?"))await persist(kind,item,true);}
  });
  $("#ideaFilters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;filter=b.dataset.filter;$("#ideaFilters").querySelectorAll("button").forEach(x=>x.classList.toggle("selected",x===b));renderIdeas();});
  const letters={
    bad:"Se hoje estiver sendo um dia difícil, não precisa resolver tudo agora. Respira um pouco, toma uma água e lembra que você não precisa fingir estar bem o tempo inteiro. Se quiser conversar, eu estou por aqui. ♡",
    miss:"Se bateu saudade, fica aqui um pouquinho. Escolhe uma música, lembra de alguma das nossas conversas e me chama quando quiser. Gosto de dividir meus dias com você, mesmo de longe.",
    good:"Eu espero que você tenha contado essa notícia para alguém e comemorado do seu jeito. Não diminui suas conquistas. Você se esforça muito e merece reconhecer cada passo que dá. Quero saber de tudo!"
  };
  document.querySelectorAll(".letter-card").forEach(b=>b.addEventListener("click",()=>{$("#letterText").textContent=letters[b.dataset.letter];$("#letterReveal").hidden=false;$("#letterReveal").scrollIntoView({behavior:"smooth",block:"center"});}));
  $("#closeLetter").addEventListener("click",()=>$("#letterReveal").hidden=true);
  $("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
  document.querySelectorAll(".nav-link").forEach(a=>a.addEventListener("click",()=>{$("#mainNav").classList.remove("open");document.querySelectorAll(".nav-link").forEach(x=>x.classList.toggle("active",x===a));}));
  $("#openSettings").addEventListener("click",()=>$("#settingsDialog").showModal());

  function loadConfig(){try{return JSON.parse(localStorage.getItem(CONFIG_KEY)||"null");}catch{return null;}}
  async function connect(){
    const cfg=loadConfig();if(!cfg?.url||!cfg?.key||!window.supabase)return;
    supabase=window.supabase.createClient(cfg.url,cfg.key);
    const {data:sessionData}=await supabase.auth.getSession();user=sessionData.session?.user||null;
    supabase.auth.onAuthStateChange((_event,session)=>{user=session?.user||null;updateConnectionUI();});
    updateConnectionUI();
    if(user&&roomId)await syncFromCloud();
  }
  function updateConnectionUI(){
    const banner=$("#syncStatus");
    if(user&&roomId){banner.classList.add("connected");banner.innerHTML='<span class="status-dot"></span><span>Conectado ao espaço compartilhado. As alterações são sincronizadas.</span><button id="openSettings" class="text-btn">Conta</button>';$("#openSettings").addEventListener("click",()=>$("#settingsDialog").showModal());}
    else {banner.classList.remove("connected");banner.innerHTML='<span class="status-dot"></span><span>Modo local: configure a conexão para compartilhar entre dispositivos.</span><button id="openSettings" class="text-btn">Configurar</button>';$("#openSettings").addEventListener("click",()=>$("#settingsDialog").showModal());}
    $("#signOut").hidden=!user;$("#roomArea").hidden=!user;
  }
  async function syncFromCloud(){
    if(!supabase||!user||!roomId)return;
    const {data:rows,error}=await supabase.from("shared_items").select("*").eq("room_id",roomId).order("created_at",{ascending:false});
    if(error){toast("Não foi possível carregar o espaço: "+error.message);return;}
    const cloud={ideas:[],memories:[],songs:[]};
    (rows||[]).forEach(r=>{if(cloud[r.kind])cloud[r.kind].push(r.payload);});
    data=cloud;saveLocal();render();toast("Espaço compartilhado carregado.");
    const channel=supabase.channel("room-"+roomId).on("postgres_changes",{event:"*",schema:"public",table:"shared_items",filter:`room_id=eq.${roomId}`},()=>syncFromCloud()).subscribe();
  }
  $("#saveSettings").addEventListener("click",async()=>{
    const url=$("#supabaseUrl").value.trim(),key=$("#supabaseKey").value.trim();
    if(!url||!key){setMessage("Preencha a URL e a chave pública do Supabase.");return;}
    localStorage.setItem(CONFIG_KEY,JSON.stringify({url,key}));await connect();setMessage("Configuração salva neste navegador.");
  });
  const cfg=loadConfig();if(cfg){$("#supabaseUrl").value=cfg.url;$("#supabaseKey").value=cfg.key;}
  $("#signUp").addEventListener("click",async()=>{
    if(!supabase){setMessage("Salve primeiro as configurações do Supabase.");return;}
    const email=$("#authEmail").value.trim(),password=$("#authPassword").value;
    const {error}=await supabase.auth.signUp({email,password});setMessage(error?error.message:"Conta criada. Se a confirmação de e-mail estiver ativa, confirme o endereço antes de entrar.");
  });
  $("#signIn").addEventListener("click",async()=>{
    if(!supabase){setMessage("Salve primeiro as configurações do Supabase.");return;}
    const {data:d,error}=await supabase.auth.signInWithPassword({email:$("#authEmail").value.trim(),password:$("#authPassword").value});
    if(error){setMessage(error.message);return;}user=d.user;updateConnectionUI();if(roomId)await syncFromCloud();setMessage("Você entrou na sua conta.");
  });
  $("#signOut").addEventListener("click",async()=>{if(supabase)await supabase.auth.signOut();user=null;roomId=null;localStorage.removeItem(ROOM_KEY);updateConnectionUI();setMessage("Você saiu da conta.");});
  $("#createRoom").addEventListener("click",async()=>{
    if(!supabase||!user){setMessage("Entre na sua conta primeiro.");return;}
    const code=Array.from(crypto.getRandomValues(new Uint8Array(8))).map(x=>"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[x%32]).join("");
    const {data:room,error}=await supabase.from("rooms").insert({name:$("#roomName").value.trim()||"Nosso cantinho",invite_code:code,created_by:user.id}).select().single();
    if(error){setMessage(error.message);return;}
    const {error:memberError}=await supabase.from("room_members").insert({room_id:room.id,user_id:user.id});
    if(memberError){setMessage(memberError.message);return;}
    roomId=room.id;localStorage.setItem(ROOM_KEY,roomId);$("#roomInfo").textContent="Código para compartilhar: "+code;updateConnectionUI();await syncFromCloud();setMessage("Espaço criado! Envie o código para a outra pessoa.");
  });
  $("#joinRoom").addEventListener("click",async()=>{
    if(!supabase||!user){setMessage("Entre na sua conta primeiro.");return;}
    const code=$("#inviteCode").value.trim().toUpperCase();if(!code){setMessage("Digite o código de convite.");return;}
    const {data:result,error}=await supabase.rpc("join_shared_room",{p_invite_code:code});
    if(error){setMessage(error.message);return;}
    roomId=result;localStorage.setItem(ROOM_KEY,roomId);updateConnectionUI();await syncFromCloud();setMessage("Você entrou no espaço compartilhado!");
  });
  connect().catch(e=>setMessage(e.message));
  render();
})();