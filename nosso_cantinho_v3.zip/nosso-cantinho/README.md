# Nosso cantinho ♡

Site estático, responsivo e em português. Tem:
- contador automático desde **09/11/2025** e contagem regressiva para o próximo 09/11;
- linha do tempo;
- lista compartilhável de ideias (jogar, assistir, fazer e outras);
- caixinha de memórias;
- cartinhas reveláveis;
- trilha sonora com links.

## 1. Publicar no GitHub Pages
1. Extraia o ZIP.
2. Envie `index.html`, as pastas `css/` e `js/` e o arquivo `supabase-setup.sql` para a raiz do repositório.
3. No GitHub, abra **Settings > Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**, branch `main` e pasta `/(root)`.
5. Salve e aguarde a publicação.

O site funciona imediatamente em modo local, mas nesse modo os dados ficam apenas no navegador em que foram adicionados.

## 2. Ativar compartilhamento entre os dois
O compartilhamento usa Supabase (plano gratuito pode atender a um projeto pequeno). É preciso fazer esta configuração uma vez:

1. Crie um projeto em https://supabase.com/.
2. No painel do projeto, abra **SQL Editor > New query**.
3. Cole todo o conteúdo de `supabase-setup.sql` e execute.
4. Em **Project Settings > API**, copie a **Project URL** e a chave pública **anon / publishable**. Nunca use `service_role` ou chave secreta no site.
5. Abra o site, clique em **Configurar**, cole URL e chave e salve.
6. Cada pessoa deve criar sua própria conta com e-mail e senha. Se o Supabase pedir confirmação de e-mail, confirmem pelo e-mail recebido.
7. Uma pessoa entra, abre Configurar e clica em **Criar espaço compartilhado**. O site mostra um código de convite.
8. Envie esse código para a outra pessoa. Ela entra na própria conta, cola o código e clica em **Entrar em um espaço**.

Depois disso, lista, memórias e músicas são gravadas no espaço compartilhado e carregadas nos dois dispositivos. A sincronização em tempo real exige habilitar `shared_items` em **Database > Publications > supabase_realtime** no painel Supabase.

### Segurança
- As contas são individuais; não compartilhem senha.
- A chave `anon`/`publishable` foi feita para uso no navegador. As regras de Row Level Security do SQL limitam os dados aos membros do espaço.
- Não coloque a chave `service_role` no HTML ou JavaScript.
- O código de convite deve ser compartilhado apenas com a pessoa convidada.

## 3. Personalizar
- Data do marco: em `js/script.js`, procure `new Date(2025,10,9,0,0,0)`. O mês é contado a partir de zero: `10` significa novembro.
- Textos das cartinhas: objeto `letters` em `js/script.js`.
- Textos e cores: `css/style.css`.

## Observações
- O contador considera 09/11/2025 como o início do segundo ano (um ano completo em 09/11/2026).
- O conteúdo é salvo localmente antes de sincronizar. Se houver erro de conexão, a interface avisa.
- Para a playlist, o site guarda nomes e links; a reprodução é aberta no serviço do link.
