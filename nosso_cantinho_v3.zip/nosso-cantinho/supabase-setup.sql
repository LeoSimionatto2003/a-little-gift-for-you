-- Execute este arquivo no SQL Editor do seu projeto Supabase.
-- Acesso por contas individuais + associação a um espaço compartilhado.
create extension if not exists pgcrypto;

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Nosso cantinho',
  invite_code text not null unique,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.room_members (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table if not exists public.shared_items (
  id text primary key,
  room_id uuid not null references public.rooms(id) on delete cascade,
  kind text not null check (kind in ('ideas','memories','songs')),
  payload jsonb not null,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.shared_items enable row level security;

-- Helper SECURITY DEFINER evita recursão de RLS ao consultar room_members
-- a partir das políticas das próprias tabelas.
create or replace function public.is_room_member(p_room_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.room_members
    where room_id = p_room_id and user_id = auth.uid()
  );
$$;
grant execute on function public.is_room_member(uuid) to authenticated;


drop policy if exists "room creator can create room" on public.rooms;
create policy "room creator can create room" on public.rooms
for insert to authenticated with check (created_by = auth.uid());

drop policy if exists "members can view their rooms" on public.rooms;
create policy "members can view their rooms" on public.rooms
for select to authenticated using (
  public.is_room_member(id)
);

drop policy if exists "users can add themselves to own room" on public.room_members;
create policy "users can add themselves to own room" on public.room_members
for insert to authenticated with check (
  user_id = auth.uid() and exists (
    select 1 from public.rooms r where r.id = room_id and r.created_by = auth.uid()
  )
);

drop policy if exists "members can view membership" on public.room_members;
create policy "members can view membership" on public.room_members
for select to authenticated using (
  public.is_room_member(room_id)
);

drop policy if exists "members can read shared items" on public.shared_items;
create policy "members can read shared items" on public.shared_items
for select to authenticated using (
  public.is_room_member(room_id)
);

drop policy if exists "members can add shared items" on public.shared_items;
create policy "members can add shared items" on public.shared_items
for insert to authenticated with check (
  created_by = auth.uid() and public.is_room_member(room_id)
);

drop policy if exists "members can update shared items" on public.shared_items;
create policy "members can update shared items" on public.shared_items
for update to authenticated using (
  public.is_room_member(room_id)
) with check (
  public.is_room_member(room_id)
);

drop policy if exists "members can delete shared items" on public.shared_items;
create policy "members can delete shared items" on public.shared_items
for delete to authenticated using (
  public.is_room_member(room_id)
);

create or replace function public.join_shared_room(p_invite_code text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  target_room uuid;
begin
  if auth.uid() is null then
    raise exception 'Faça login antes de entrar no espaço.';
  end if;
  select id into target_room
  from public.rooms
  where invite_code = upper(trim(p_invite_code));
  if target_room is null then
    raise exception 'Código de convite não encontrado.';
  end if;
  insert into public.room_members(room_id, user_id)
  values (target_room, auth.uid())
  on conflict do nothing;
  return target_room;
end;
$$;

grant execute on function public.join_shared_room(text) to authenticated;
grant usage on schema public to authenticated;
grant select, insert on public.rooms to authenticated;
grant select, insert on public.room_members to authenticated;
grant select, insert, update, delete on public.shared_items to authenticated;

-- Realtime: habilite a tabela shared_items em Database > Publications > supabase_realtime
